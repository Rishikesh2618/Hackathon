"""
app.py  –  Kisan Call Centre Query Assistant
Streamlit frontend: accepts farmer queries, runs the RAG pipeline,
and displays both offline (FAISS) and online (IBM Granite LLM) answers.
"""

import sys
import os

# Allow imports from project root
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import streamlit as st
from services.query_handler import get_answer

# ─────────────────────────────────────────────────────────────────────────────
# Page configuration
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="KCC Query Assistant",
    page_icon="🌾",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ─────────────────────────────────────────────────────────────────────────────
# Custom CSS – matches the look from the project report screenshots
# ─────────────────────────────────────────────────────────────────────────────
st.markdown(
    """
    <style>
        /* ── Global ────────────────────────────────────────────────────── */
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;600&family=Inter:wght@400;500;600;700&display=swap');

        html, body, [class*="css"] {
            font-family: 'Inter', sans-serif;
        }

        /* Hide default Streamlit chrome */
        #MainMenu, footer, header { visibility: hidden; }

        .block-container {
            max-width: 820px;
            padding-top: 2rem;
            padding-bottom: 4rem;
        }

        /* ── Header ────────────────────────────────────────────────────── */
        .kcc-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 0.3rem;
        }
        .kcc-header-icon {
            font-size: 3rem;
            line-height: 1;
        }
        .kcc-title {
            font-size: 2.4rem;
            font-weight: 700;
            color: #1a1a1a;
            line-height: 1.15;
            margin: 0;
        }
        .kcc-subtitle {
            color: #555;
            font-size: 0.97rem;
            margin-bottom: 1.6rem;
        }

        /* ── Query Input Card ───────────────────────────────────────────── */
        .query-label {
            font-size: 0.9rem;
            font-weight: 500;
            color: #444;
            margin-bottom: 4px;
        }

        /* Streamlit text_input override */
        .stTextInput > div > div > input {
            border-radius: 6px;
            border: 1.5px solid #d0d7de;
            padding: 10px 14px;
            font-size: 1rem;
            background: #fff;
            transition: border-color 0.2s;
        }
        .stTextInput > div > div > input:focus {
            border-color: #2e7d32;
            box-shadow: 0 0 0 3px rgba(46,125,50,0.12);
        }

        /* Get Answer button */
        .stButton > button {
            background: #e8f5e9;
            color: #1b5e20;
            border: 1.5px solid #a5d6a7;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.95rem;
            padding: 8px 28px;
            cursor: pointer;
            transition: background 0.2s, border-color 0.2s;
        }
        .stButton > button:hover {
            background: #c8e6c9;
            border-color: #66bb6a;
        }

        /* ── Answer Cards ───────────────────────────────────────────────── */
        .answer-card {
            border-radius: 10px;
            padding: 1.4rem 1.6rem;
            margin-top: 1.4rem;
        }

        /* Offline card */
        .offline-card {
            background: #f8fbff;
            border: 1.5px solid #90caf9;
        }
        .offline-card .card-title {
            color: #1565c0;
        }
        .offline-card .card-icon { color: #1976d2; }

        /* Online card */
        .online-card {
            background: #fff8f0;
            border: 1.5px solid #ffb74d;
        }
        .online-card .card-title {
            color: #e65100;
        }
        .online-card .card-icon { color: #f57c00; }

        .card-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 0.9rem;
        }
        .card-icon { font-size: 1.6rem; }
        .card-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
        }

        .sub-label {
            font-size: 0.82rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #777;
            margin-bottom: 0.5rem;
        }

        /* Numbered offline list */
        .offline-list {
            padding-left: 1.2rem;
            margin: 0;
        }
        .offline-list li {
            margin-bottom: 0.7rem;
            line-height: 1.65;
            font-size: 0.97rem;
            font-family: 'Noto Sans Devanagari', 'Inter', sans-serif;
            color: #212121;
        }

        /* Online prose */
        .online-prose {
            font-size: 0.97rem;
            line-height: 1.75;
            color: #2d2d2d;
        }

        /* ── Expert recommendation badge ───────────────────────────────── */
        .expert-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #e8f5e9;
            border: 1.2px solid #a5d6a7;
            border-radius: 20px;
            padding: 4px 14px;
            font-size: 0.82rem;
            font-weight: 600;
            color: #2e7d32;
            margin-bottom: 1.2rem;
        }

        /* ── Divider ───────────────────────────────────────────────────── */
        .section-divider {
            border: none;
            border-top: 1.5px solid #ebebeb;
            margin: 1.8rem 0;
        }

        /* ── Warning / info boxes ──────────────────────────────────────── */
        .stAlert { border-radius: 8px; }
    </style>
    """,
    unsafe_allow_html=True,
)

# ─────────────────────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────────────────────
st.markdown(
    """
    <div class="kcc-header">
        <span class="kcc-header-icon">🌾</span>
        <h1 class="kcc-title">Kisan Call Centre Query<br>Assistant</h1>
    </div>
    <p class="kcc-subtitle">
        Ask your farming or crop-related question and get a reliable response
        powered by IBM Watsonx Granite LLM and KCC database.
    </p>
    """,
    unsafe_allow_html=True,
)

# ─────────────────────────────────────────────────────────────────────────────
# Input section
# ─────────────────────────────────────────────────────────────────────────────
st.markdown('<p class="query-label">🌱 Enter your agricultural query:</p>', unsafe_allow_html=True)

query = st.text_input(
    label="query",
    placeholder="e.g., How to control whiteflies in cotton?",
    label_visibility="collapsed",
)

col1, col2 = st.columns([1, 5])
with col1:
    submitted = st.button("Get Answer")

# ─────────────────────────────────────────────────────────────────────────────
# Answer section
# ─────────────────────────────────────────────────────────────────────────────
if submitted:
    if not query.strip():
        st.warning("⚠️ Please enter a question.")
    else:
        with st.spinner("Searching KCC database and consulting IBM Granite LLM…"):
            try:
                response = get_answer(query.strip(), use_llm=True, top_k=5)
            except Exception as e:
                st.error(f"Pipeline error: {e}")
                st.stop()

        # ── Expert badge ──────────────────────────────────────────────────
        st.markdown(
            '<div class="expert-badge">✅ Expert Recommendations</div>',
            unsafe_allow_html=True,
        )

        # ── Offline answer card ───────────────────────────────────────────
        offline_html = ""
        if response["results"]:
            items = "".join(
                f"<li>{r['answer']}</li>" for r in response["results"]
            )
            offline_html = f'<ol class="offline-list">{items}</ol>'
        else:
            offline_html = "<p>No relevant records found in the KCC database.</p>"

        st.markdown(
            f"""
            <div class="answer-card offline-card">
                <div class="card-header">
                    <span class="card-icon">🔷</span>
                    <h2 class="card-title">Retrieved Answer (Offline - Based on KCC Data):</h2>
                </div>
                <p class="sub-label">🔷 Offline Answer (retrieved Q&amp;A):</p>
                {offline_html}
            </div>
            """,
            unsafe_allow_html=True,
        )

        # ── Online / LLM answer card ──────────────────────────────────────
        llm_text = response.get("online_answer") or "LLM answer unavailable."

        st.markdown(
            f"""
            <div class="answer-card online-card">
                <div class="card-header">
                    <span class="card-icon">🧠</span>
                    <h2 class="card-title">LLM Answer (Online - IBM Granite):</h2>
                </div>
                <p class="sub-label">🧠 Online Answer (LLM):</p>
                <p class="online-prose">{llm_text}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )

# ─────────────────────────────────────────────────────────────────────────────
# Footer / Sample queries hint
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 💡 Sample Queries")
    samples = [
        "How to control aphids in mustard?",
        "What is the treatment for leaf spot in tomato?",
        "Suggest pesticide for whitefly in cotton.",
        "How to prevent fruit borer in brinjal?",
        "What fertilizer during flowering in maize?",
        "How to protect paddy from blast disease?",
        "What is the solution for jassids in cotton?",
        "How to apply for PM Kisan Samman Nidhi?",
        "Dosage of neem oil for aphids?",
        "How to treat blight in potato crops?",
    ]
    for s in samples:
        st.markdown(f"- {s}")

    st.markdown("---")
    st.markdown("### ⚙️ Configuration")
    st.markdown(
        "Add IBM Watsonx credentials to `.env`:\n"
        "```\nWATSONX_PROJECT_ID=...\nWATSONX_API_KEY=...\nMODEL_ID=ibm/granite-3-8b-instruct\n```"
    )
