"""
faiss_indexer.py
Builds and manages a FAISS vector index over KCC Q&A embeddings.
"""

import faiss
import pickle
import numpy as np
import os


class FAISSVectorStore:
    """FAISS-backed vector store for fast semantic similarity search."""

    def __init__(
        self,
        dim: int = 384,
        index_path: str = "vector_store/faiss.index",
        meta_path: str = "vector_store/meta.pkl",
    ):
        self.dim = dim
        self.index_path = index_path
        self.meta_path = meta_path
        # Use flat L2 index for exact search (good for datasets < 1M)
        self.index = faiss.IndexFlatL2(dim)
        self.metadata = []

    # ------------------------------------------------------------------
    # Building the index
    # ------------------------------------------------------------------

    def build_index(self, embeddings_file: str):
        """
        Load pre-computed embeddings from pickle, add them to the FAISS index,
        and cache the associated metadata.

        Args:
            embeddings_file: Path to the pickle produced by generate_embeddings.py
        """
        with open(embeddings_file, "rb") as f:
            records = pickle.load(f)

        vectors = np.array(
            [record["embedding"] for record in records], dtype="float32"
        )
        self.metadata = [record["metadata"] for record in records]

        # Normalise vectors (optional – improves cosine-like behaviour)
        faiss.normalize_L2(vectors)

        self.index.add(vectors)
        print(f"✓ FAISS index built with {self.index.ntotal} vectors (dim={self.dim})")

    def save_index(self):
        """Persist the FAISS index and metadata to disk."""
        os.makedirs(os.path.dirname(self.index_path), exist_ok=True)
        faiss.write_index(self.index, self.index_path)
        with open(self.meta_path, "wb") as f:
            pickle.dump(self.metadata, f)
        print(f"✓ Index saved to {self.index_path}")
        print(f"✓ Metadata saved to {self.meta_path}")

    # ------------------------------------------------------------------
    # Loading the index
    # ------------------------------------------------------------------

    def load_index(self):
        """Load a previously saved FAISS index and metadata from disk."""
        if not os.path.exists(self.index_path):
            raise FileNotFoundError(
                f"FAISS index not found at {self.index_path}. "
                "Run build_faiss.py first."
            )
        self.index = faiss.read_index(self.index_path)
        with open(self.meta_path, "rb") as f:
            self.metadata = pickle.load(f)
        print(f"✓ Loaded FAISS index ({self.index.ntotal} vectors)")

    # ------------------------------------------------------------------
    # Searching the index
    # ------------------------------------------------------------------

    def search(self, query_vector: np.ndarray, top_k: int = 5):
        """
        Return the top-k most similar metadata entries for a query vector.

        Args:
            query_vector: 1-D float32 numpy array of shape (dim,)
            top_k:        Number of results to return (with deduplication buffer)

        Returns:
            List of metadata dicts (question, answer, state, district, crop)
        """
        query_vec = query_vector.astype("float32").reshape(1, -1)
        faiss.normalize_L2(query_vec)

        # Fetch extra results to allow deduplication
        distances, indices = self.index.search(query_vec, top_k + 10)

        seen_answers = set()
        results = []
        for idx in indices[0]:
            if 0 <= idx < len(self.metadata):
                answer = self.metadata[idx]["answer"].strip()
                if answer not in seen_answers:
                    seen_answers.add(answer)
                    results.append(self.metadata[idx])
            if len(results) >= top_k:
                break

        return results
