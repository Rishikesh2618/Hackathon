"""
build_faiss.py
One-shot script: builds the FAISS index from pre-computed embeddings.
Run AFTER generate_embeddings.py.
"""

import sys
import os

# Allow running from project root
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from vector_store.faiss_indexer import FAISSVectorStore

if __name__ == "__main__":
    vs = FAISSVectorStore(dim=384)          # all-MiniLM-L6-v2 → 384 dims
    vs.build_index("embeddings/kcc_embeddings.pkl")
    vs.save_index()
    print("FAISS vector store ready.")
