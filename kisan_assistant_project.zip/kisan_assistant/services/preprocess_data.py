"""
preprocess_data.py
Cleans raw KCC CSV and produces clean_kcc.csv + kcc_qa_pairs.json
"""

import pandas as pd
import json
import os
import re


def clean_text(text: str) -> str:
    """Basic text cleaning."""
    if not isinstance(text, str):
        return ""
    text = text.strip()
    text = re.sub(r'\s+', ' ', text)
    return text


def preprocess_data(input_csv: str = "data/raw_kcc.csv",
                    output_csv: str = "data/clean_kcc.csv",
                    output_json: str = "data/kcc_qa_pairs.json"):
    """
    Load raw KCC CSV, clean Q&A pairs, remove duplicates,
    and save to CSV + JSON formats.
    """
    print(f"Loading raw data from: {input_csv}")
    df = pd.read_csv(input_csv, encoding="utf-8")

    print(f"Raw records: {len(df)}")

    # Standardize column names
    df.columns = [c.strip() for c in df.columns]

    # Rename to standard names if needed
    rename_map = {}
    for col in df.columns:
        lower = col.lower()
        if "querytext" in lower or "query_text" in lower:
            rename_map[col] = "QueryText"
        elif "kccans" in lower or "kcc_ans" in lower or "answer" in lower:
            rename_map[col] = "KccAns"
        elif "statename" in lower:
            rename_map[col] = "StateName"
        elif "districtname" in lower:
            rename_map[col] = "DistrictName"
        elif "crop" in lower:
            rename_map[col] = "Crop"
    if rename_map:
        df.rename(columns=rename_map, inplace=True)

    # Keep only rows with non-empty Q and A
    df = df.dropna(subset=["QueryText", "KccAns"])
    df["QueryText"] = df["QueryText"].apply(clean_text)
    df["KccAns"] = df["KccAns"].apply(clean_text)

    # Drop rows with very short answers
    df = df[df["QueryText"].str.len() > 5]
    df = df[df["KccAns"].str.len() > 10]

    # Normalize state/district capitalization
    if "StateName" in df.columns:
        df["StateName"] = df["StateName"].str.title()
    if "DistrictName" in df.columns:
        df["DistrictName"] = df["DistrictName"].str.title()

    # Drop duplicate Q&A pairs
    df.drop_duplicates(subset=["QueryText", "KccAns"], inplace=True)
    df.reset_index(drop=True, inplace=True)

    print(f"Clean records after deduplication: {len(df)}")

    # Save cleaned CSV
    os.makedirs(os.path.dirname(output_csv), exist_ok=True)
    df.to_csv(output_csv, index=False, encoding="utf-8")
    print(f"Saved clean CSV to: {output_csv}")

    # Build Q&A pairs JSON
    qa_pairs = []
    for _, row in df.iterrows():
        entry = {
            "question": row["QueryText"],
            "answer": row["KccAns"],
            "state": row.get("StateName", ""),
            "district": row.get("DistrictName", ""),
            "crop": row.get("Crop", ""),
        }
        qa_pairs.append(entry)

    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(qa_pairs, f, ensure_ascii=False, indent=2)

    print(f"Saved {len(qa_pairs)} Q&A pairs to: {output_json}")
    return qa_pairs


if __name__ == "__main__":
    preprocess_data()
