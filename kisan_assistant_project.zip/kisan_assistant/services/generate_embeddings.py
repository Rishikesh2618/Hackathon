"""
generate_embeddings.py
Converts KCC Q&A pairs into dense vector embeddings using SentenceTransformer.
Saves embeddings to a pickle file for later FAISS indexing.
"""

import json
import os
import pickle
from sentence_transformers import SentenceTransformer


def generate_embeddings(
    input_json: str = "data/kcc_qa_pairs.json",
    output_pickle: str = "embeddings/kcc_embeddings.pkl",
    model_name: str = "all-MiniLM-L6-v2",
):
    """
    Load Q&A data, generate sentence embeddings, and save to pickle.

    Args:
        input_json:     Path to the cleaned Q&A JSON file.
        output_pickle:  Path where the embedding records will be saved.
        model_name:     SentenceTransformer model to use.
    """
    # Load the Q&A data
    with open(input_json, "r", encoding="utf-8") as f:
        qa_data = json.load(f)

    print(f"Loaded {len(qa_data)} Q&A pairs from {input_json}")

    # Initialize SentenceTransformer model
    print(f"Loading model: {model_name}")
    model = SentenceTransformer(model_name)

    # Prepare texts to embed  (question + answer combined for richer semantics)
    texts = [f"Q: {item['question']} A: {item['answer']}" for item in qa_data]

    # Generate embeddings
    print("Generating embeddings...")
    embeddings = model.encode(texts, show_progress_bar=True, batch_size=32)

    # Save as a list of (embedding, metadata) records
    embedded_records = []
    for vec, item in zip(embeddings, qa_data):
        embedded_records.append({
            "embedding": vec,
            "metadata": item,
        })

    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_pickle), exist_ok=True)

    with open(output_pickle, "wb") as f:
        pickle.dump(embedded_records, f)

    print(f"✓ Embeddings generated and saved to: {output_pickle}")
    print(f"  Embedding dimension: {embeddings.shape[1]}")
    return embedded_records


if __name__ == "__main__":
    generate_embeddings(
        input_json="data/kcc_qa_pairs.json",
        output_pickle="embeddings/kcc_embeddings.pkl",
    )
