"""
query_handler.py
Core service: embeds user query → retrieves top-k via FAISS → optionally calls Granite LLM.
"""

import os
import sys
import pickle
import numpy as np

# Ensure project root is on path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sentence_transformers import SentenceTransformer
from vector_store.faiss_indexer import FAISSVectorStore
from models.granite_llm import call_granite_llm

# ---------------------------------------------------------------------------
# Lazy-loaded singletons (loaded once per Streamlit session)
# ---------------------------------------------------------------------------
_embedding_model = None
_vector_store = None


def _load_resources():
    """Load the sentence-transformer model and FAISS index (once)."""
    global _embedding_model, _vector_store

    if _embedding_model is None:
        _embedding_model = SentenceTransformer("all-MiniLM-L6-v2")

    if _vector_store is None:
        vs = FAISSVectorStore(dim=384)
        try:
            vs.load_index()
        except FileNotFoundError:
            # Auto-build if running for the first time
            _auto_setup(vs)
        _vector_store = vs


def _auto_setup(vs: FAISSVectorStore):
    """Run full pipeline if FAISS index doesn't exist yet."""
    import subprocess, sys

    # Preprocess
    if not os.path.exists("data/kcc_qa_pairs.json"):
        from services.preprocess_data import preprocess_data
        preprocess_data()

    # Embeddings
    if not os.path.exists("embeddings/kcc_embeddings.pkl"):
        from services.generate_embeddings import generate_embeddings
        generate_embeddings()

    # Build FAISS
    vs.build_index("embeddings/kcc_embeddings.pkl")
    vs.save_index()


def search_top_k(query: str, top_k: int = 5):
    """
    Return top-k most semantically similar Q&A entries for the given query.

    Args:
        query:  User's natural language question.
        top_k:  Number of unique results to return.

    Returns:
        List of metadata dicts with 'question', 'answer', 'crop', etc.
    """
    _load_resources()

    query_vec = _embedding_model.encode([query])[0].astype("float32")
    results = _vector_store.search(query_vec, top_k=top_k)
    return results


def format_offline_answer(results: list) -> str:
    """Format retrieved Q&A pairs as a numbered list for offline display."""
    if not results:
        return "No relevant information found in the KCC database for this query."

    lines = []
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['answer']}")
    return "\n\n".join(lines)


def build_llm_prompt(query: str, results: list) -> str:
    """Construct a RAG prompt from the retrieved context entries."""
    context_parts = []
    for r in results:
        context_parts.append(f"Q: {r['question']}\nA: {r['answer']}")

    context = "\n\n".join(context_parts)
    prompt = (
        f"Based on the following agricultural expert answers from the Kisan Call Centre:\n\n"
        f"{context}\n\n"
        f"Now answer this farmer's question clearly and concisely in English:\n"
        f"Question: {query}\n\n"
        f"Answer:"
    )
    return prompt


def get_answer(query: str, use_llm: bool = True, top_k: int = 5) -> dict:
    """
    Full pipeline: retrieve → (optionally) generate.

    Returns:
        dict with keys:
            'offline_answer'  – formatted retrieved Q&A
            'online_answer'   – LLM-generated answer (or None)
            'results'         – raw list of top-k metadata dicts
    """
    results = search_top_k(query, top_k=top_k)
    offline_answer = format_offline_answer(results)

    online_answer = None
    if use_llm:
        prompt = build_llm_prompt(query, results)
        online_answer = call_granite_llm(prompt)

    return {
        "offline_answer": offline_answer,
        "online_answer": online_answer,
        "results": results,
    }
