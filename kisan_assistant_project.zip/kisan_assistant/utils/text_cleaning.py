"""
text_cleaning.py
Shared text utility functions used across the pipeline.
"""

import re
import unicodedata


def normalize_unicode(text: str) -> str:
    """Normalize unicode characters to NFC form."""
    return unicodedata.normalize("NFC", text)


def clean_whitespace(text: str) -> str:
    """Collapse multiple spaces/newlines into single spaces."""
    return re.sub(r"\s+", " ", text).strip()


def remove_special_chars(text: str, keep_hindi: bool = True) -> str:
    """
    Remove unwanted special characters while optionally preserving
    Devanagari (Hindi) unicode range U+0900–U+097F.
    """
    if keep_hindi:
        # Allow ASCII printable + Devanagari block
        pattern = r"[^\x20-\x7E\u0900-\u097F]"
    else:
        pattern = r"[^\x20-\x7E]"
    return re.sub(pattern, "", text)


def clean_query(query: str) -> str:
    """Prepare a user query for embedding."""
    query = normalize_unicode(query)
    query = clean_whitespace(query)
    return query


def clean_answer(answer: str) -> str:
    """Prepare a KCC answer for storage and display."""
    answer = normalize_unicode(answer)
    answer = clean_whitespace(answer)
    return answer
